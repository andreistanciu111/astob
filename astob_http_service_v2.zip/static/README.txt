Put template here named exactly: bp model cu {}.xlsx
Optional: CLIENTI_TOTAL_PESTE_0_ONE_ROW_HEADERS_SINGLE_DETAILS_TOTAL_TOP.zip
